package in.ineuron;

public class ShuffleArray {
	    public static int[] shuffle(int[] nums, int n) {
	        
	        int len = nums.length;
	        
	        for(int i = n; i < len; i++) {
	            nums[i] = (nums[i] << 10) | nums[i - n];
	        }
	        
	        int index = 0;
	        for(int i = n; i < len; i++, index += 2) {
	            nums[index] = nums[i] & 1023;
	            nums[index + 1] = nums[i] >>> 10;
	        }
	        
	        return nums;
	    }
	    
	    public static void main(String[] args) {
			
	    	int nums[]= {2,5,1,3,4,7};
	    	int n=3;
	    	int[] result =new int[10];
	    	result=shuffle(nums,n); 
	    	for(int i:result) {
	    		System.out.println(i);
	    	}
	    	
		}
	}



