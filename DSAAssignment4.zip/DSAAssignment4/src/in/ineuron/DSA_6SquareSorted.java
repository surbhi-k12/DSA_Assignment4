package in.ineuron;

public class DSA_6SquareSorted {

	    public  static int[] sortedSquares(int[] nums) {
	        int length = nums.length;
	        if (length == 0) return new int[0];
	        
	        int[] result = new int[length];
	        int l = 0, r = length - 1;
	        for (int i = length - 1; i >= 0; i--) {
	            int start = nums[l] * nums[l];
	            int end = nums[r] * nums[r];
	            if (start > end) {
	                result[i] = start;
	                l++;
	            } else {
	                result[i] = end;
	                r--;
	            }
	        }
	        return result;
	    }
	    
	    public static void main(String[] args) {
			int[] n= {-4,-1,0,3,10};
			int[] k=new int[5];
			k=sortedSquares(n);
			for(int i : k) {
				System.out.println(i);
			}
			
		}
	}


